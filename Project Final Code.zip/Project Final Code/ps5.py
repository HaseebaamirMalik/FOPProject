import re
import feedparser
import string
import time
import threading
from datetime import datetime
import pytz
import tkinter as tk
from tkinter import Frame, Scrollbar, StringVar, Label, Text, Button
from bs4 import BeautifulSoup

class NewsStory:
    def __init__(self, g, t, d, l, p):
        self.G = g
        self.T = t
        self.D = d
        self.L = l
        self.P = p

    def GetG(self):
        return self.G

    def GetT(self):
        return self.T

    def GetD(self):
        return self.D

    def GetL(self):
        return self.L

    def GetP(self):
        return self.P

class Trigger:
    def Eval(self, s):
        raise NotImplementedError

class PhraseTrigger(Trigger):
    def __init__(self, phrase):
        self.Phrase = phrase.lower()

    def IsIn(self, text):
        text = text.lower()
        for p in string.punctuation:
            text = text.replace(p, ' ')
        words = text.split()
        phrase_words = self.Phrase.split()
        return ' '.join(words).find(' '.join(phrase_words)) != -1

class TitleTrigger(PhraseTrigger):
    def Eval(self, s):
        return self.IsIn(s.T)

class DescriptionTrigger(PhraseTrigger):
    def Eval(self, s):
        return self.IsIn(s.D)

class TimeTrigger(Trigger):
    def __init__(self, time):
        self.T = datetime.strptime(time, "%d %b %Y %H:%M:%S").replace(tzinfo=pytz.timezone("EST"))

class BeforeTrigger(TimeTrigger):
    def Eval(self, s):
        return s.GetP().replace(tzinfo=pytz.timezone("EST")) < self.T

class AfterTrigger(TimeTrigger):
    def Eval(self, s):
        return s.GetP().replace(tzinfo=pytz.timezone("EST")) > self.T

class NotTrigger(Trigger):
    def __init__(self, t):
        self.T = t

    def Eval(self, s):
        return not self.T.Eval(s)

class AndTrigger(Trigger):
    def __init__(self, t1, t2):
        self.T1 = t1
        self.T2 = t2

    def Eval(self, s):
        return self.T1.Eval(s) and self.T2.Eval(s)

class OrTrigger(Trigger):
    def __init__(self, t1, t2):
        self.T1 = t1
        self.T2 = t2

    def Eval(self, s):
        return self.T1.Eval(s) or self.T2.Eval(s)

def Filter(s, tlist):
    filtered_stories = []
    for story in s:
        if any(trigger.Eval(story) for trigger in tlist):
            filtered_stories.append(story)
    return filtered_stories

def ReadConfig(filename):
    trigger_file = open(filename, 'r')
    lines = []
    for line in trigger_file:
        line = line.rstrip()
        if not (len(line) == 0 or line.startswith('//')):
            lines.append(line)
    dicty = {
        'TITLE': TitleTrigger,
        'DESCRIPTION': DescriptionTrigger,
        'AND': AndTrigger,
        'OR': OrTrigger,
        'NOT': NotTrigger,
        'AFTER': AfterTrigger,
        'BEFORE': BeforeTrigger
    }
    trigger_dict = {}
    trigger_list = []
    for line in lines:
        data = re.split(",", line)
        if data[0] != 'ADD':
            if data[1] in ['TITLE', 'DESCRIPTION', 'AFTER', 'BEFORE', 'NOT']:
                trigger_dict[data[0]] = dicty[data[1]](data[2])
            elif data[1] in ['AND', 'OR']:
                trigger_dict[data[0]] = dicty[data[1]](trigger_dict[data[2]], trigger_dict[data[3]])
        elif data[0] == 'ADD':
            trigger_list.extend(trigger_dict[t] for t in data[1:])
    return trigger_list

def Process(url):
    feed = feedparser.parse(url)
    entries = feed.entries
    ret = []
    for entry in entries:
        g = entry.guid
        t = entry.title
        l = entry.link
        d = entry.description
        p = entry.published

        try:
            p = datetime.strptime(p, "%a, %d %b %Y %H:%M:%S %Z")
            p = p.replace(tzinfo=pytz.timezone("GMT"))
        except ValueError:
            p = datetime.strptime(p, "%a, %d %b %Y %H:%M:%S %z")

        newsStory = NewsStory(g, t, d, l, p)
        ret.append(newsStory)
    return ret

SLEEPTIME = 120

def UpdateGui(master, cont, scrollbar):
    try:
        triggerlist = ReadConfig('triggers.txt')
        guidShown = []

        while True:
            print("Polling . . .", end=' ')
            stories = Process("http://news.google.com/news?output=rss")
            print(f"Number of fetched stories: {len(stories)}\nFiltered Stories:")

            filtered_stories = Filter(stories, triggerlist)
            print(f"Number of filtered stories: {len(filtered_stories)}")

            cont.delete('1.0', tk.END)

            for story in filtered_stories:
                cont.insert(tk.END, f"Title: {story.GetT()}\n")
                cont.insert(tk.END, f"Description: ")
                # Parse HTML description
                soup = BeautifulSoup(story.GetD(), 'html.parser')
                description_text = soup.get_text(separator='\n')
                cont.insert(tk.END, description_text + "\n")
                cont.insert(tk.END, f"Link: {story.GetL()}\n\n")
                cont.insert(tk.END, "---------------------------------------------------------------\n\n")

            scrollbar.config(command=cont.yview)

            print("Sleeping...")
            time.sleep(SLEEPTIME)

    except Exception as e:
        print("An error occurred:", e)


def MainThread(master):
    frame = Frame(master)
    frame.pack(side=tk.BOTTOM)
    scrollbar = Scrollbar(master)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    t = "Google & Yahoo Top News"
    title = StringVar()
    title.set(t)
    ttl = Label(master, textvariable=title, font=("Times New Roman", 18))
    ttl.pack(side=tk.TOP)
    cont = Text(master, font=("Times New Roman", 14), yscrollcommand=scrollbar.set, wrap=tk.WORD)
    cont.pack(side=tk.BOTTOM)
    button = Button(frame, text="Exit", command=root.destroy)
    button.pack(side=tk.BOTTOM)

    gui_thread = threading.Thread(target=UpdateGui, args=(master, cont, scrollbar))
    gui_thread.daemon = True
    gui_thread.start()

if __name__ == '__main__':
    root = tk.Tk()
    root.title("Some RSS parser")
    MainThread(root)
    root.mainloop()

